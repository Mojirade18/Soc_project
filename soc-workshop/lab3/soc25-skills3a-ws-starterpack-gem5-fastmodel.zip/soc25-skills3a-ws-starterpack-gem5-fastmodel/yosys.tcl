#
# SoC-25 Workshop III synthesis script.
# yosys.tcl   
#
read_verilog soc25-ttpu.v

# generic synthesis
synth -top SOC25_TTPU101

# mapping to mycells.lib
dfflibmap -liberty   /home/djg11/Downloads/orfs2/content/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
abc -liberty   /home/djg11/Downloads/orfs2/content/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
clean

# write synthesized design
write_verilog synth.v

# eof
